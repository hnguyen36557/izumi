<?php

return [

    'theme' => [

        'folder' => 'themes',
        'active' => ''

    ]

];